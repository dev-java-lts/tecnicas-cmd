
// Instalar Extension Pack for Java
// Instalar TODO tree

// https://www.online-ide.com/

// https://www.youtube.com/playlist?list=PLMLmotKSEKYdhb3F3JpbtZPewb-9wZTji

/*

██░▀██████████████▀░██
█▌▒▒░████████████░▒▒▐█
█░▒▒▒░██████████░▒▒▒░█
▌░▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒░▐
░▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒░
███▀▀▀██▄▒▒▒▒▒▒▒▄██▀▀▀██
██░░░▐█░▀█▒▒▒▒▒█▀░█▌░░░█
▌░░░▐▄▌░▐▌▒▒▒▐▌░▐▄▌░░▐▌
█░░░▐█▌░░▌▒▒▒▐░░▐█▌░░█
▒▀▄▄▄█▄▄▄▌░▄░▐▄▄▄█▄▄▀▒
░░░░░░░░░░└┴┘░░░░░░░░░
██▄▄░░░░░░░░░░░░░░▄▄██
████████▒▒▒▒▒▒████████
█▀░░███▒▒░░▒░░▒▀██████
█▒░███▒▒╖░░╥░░╓▒▐█████
█▒░▀▀▀░░║░░║░░║░░█████
██▄▄▄▄▀▀┴┴╚╧╧╝╧╧╝┴┴███
██████████████████████

*/

public class Clase02{
    public static void main(String[] args) {

        //https://codeshare.io/dwlr04

        // F5 para ejecutar
        //sout |TAB| atajo de teclado para System.out.println
        System.out.println("Hola Mundo!!");
        System.out.println("Hoy es jueves!!");
        System.out.println("Centro 35");

        System.out.print("1");
        System.out.print("2");
        System.out.print("3");
        System.out.println("4");
        System.out.println("Centro Metropolitano de Diseño!");

        /*
         * Hola Mundo!!
         * Hoy es jueves!!
         * Centro 35
         * 1234
         * Centro Metropolitano de Diseño!
         * 
         */
    
        /*
         *  Memoria RAM:    Volatil         Cara            Veloz
         *  Disco DURO:     Persistente     Economico       Lento
         */

        //Variables en memoria RAM

        //Lenguajes de tipado fuerte:   Java, C, C++, C#, Visual Basic
        //Lenguajes de tipado debil:    Python, PHP, JavaScript

        //Tipo de datos primitivos
        //Tipo de datos entero
        int a;          //Declaración de variables
        a=2;            //Asignación de valor

        int b=4;        //Declaración y asignación de valor

        int c=a+b;      //6

        int d=23, e=26, f=38, g=65; //Declaración y asignación multiple

        //Una variable solo puede ser declarada una vez, 
        //Una variable puede tener infinitas asignaciones de valor
        //int a;        //Error variable ya declarada 
        a=29;
        a=39;
        a=6;

        System.out.println(a);
        System.out.println("Variable a= "+a);
        System.out.println("a+b="+a+b);     //a+b=64
        System.out.println("a+b="+(a+b));   //a+b=10

        //Tipo de datos String (cadena de texto)
        String t="Recreo";
        String v="Cafe";
        String yo="Carlos Patricio Ríos";
        System.out.println(t+v);        //RecreoCafe
        System.out.println(t+" "+v);    //Recreo Cafe
        System.out.println(t+" y "+v);  //Recreo y Cafe
        System.out.println(yo);

        //tipo de datos char 
        char ch=65;
        System.out.println(ch);
        ch+=32;
        System.out.println(ch);

        ch='G';
        System.out.println(ch);

        //Tipo de datos de punto flotante

        //Tipo de datos float 32 bits
        float fl=4.38f;
        System.out.println(fl);

        //Tipo de datos double 64 bits
        double dl=4.38;
        System.out.println(dl);

        fl=1;
        dl=1;
        System.out.println(fl/3);   //.33333334
        System.out.println(dl/3);   //.3333333333333333

        fl=10;
        dl=10;
        System.out.println(fl/3);   //3.3333333
        System.out.println(dl/3);   //3.3333333333333335

        fl=100;
        dl=100;
        System.out.println(fl/3);   
        System.out.println(dl/3);

        fl=1000000.11f;
        dl=1000000.11;
        System.out.println(fl);
        System.out.println(dl);

        dl=20000000000L;
        System.out.println(dl);

        //Tipo de datos boolean
        boolean bo=true;            // 1
        System.out.println(bo);
        bo=false;                   // 0
        System.out.println(bo);

        //Constantes
        //Las constantes son unidades de almacenamiento como las
        //variables, pertenecen a un tipo de datos primitivos.
        //Las constantes solo pueden tener una asignación de valor
        //en el momento de la declaración. No se puede volver a
        //asignar un valor a una Constante.
        System.out.println("-- Constantes");
        //final double PI=3.14;
        final double PI=Math.PI;
        //PI=4;     //Error no se puede cambiar el valor de una cte
        System.out.println(PI);

        final String centro="Centro de Formación Profesional N35";
        //centro="Centro de Formación Profesional N8";
        System.out.println(centro);


        //Operador de Asignación    =               Operador Binario
        System.out.println("-- Operador de Asignación =");
        int nro1=5;
        int nro2=7;
        System.out.println(nro1);
        System.out.println(nro2);

        nro1 = nro2;
        // <---

        System.out.println(nro1);
        System.out.println(nro2);

        //Operador Incrementales
        System.out.println("-- Operadores incrementales");
        //Sumar 1 a la variables    ++      Operador Unario
        nro1++;                 //nro1=nro1+1;
        System.out.println(nro1);

        //Restar 1 a la variable    --      Operador Unario
        nro1--;                 //nro1=nro1-1;
        //nro1=nro1-1;
        System.out.println(nro1);

        //Sumar 5 a la variable     +=      Operador Binario
        nro1+=5;                //nro1=nro1+5;
        System.out.println(nro1);

        //Restar 5 a la variable    -=      Operador Binario
        nro1-=5;                //nro1=nro1-5; 
        System.out.println(nro1);

        //Multiplicar la variable   *=      Operador Binario
        nro1*=5;                //nro1=nro1*5;
        System.out.println(nro1);

        //Dividir la variable       /=      Operador Binario
        nro1/=5;                //nro1=nro1/5   
        System.out.println(nro1);         


        //Post Incremento y Pre Incremento con operadores Unarios ++ --
        System.out.println("Post Incremente - PreIncremento");
        System.out.println(nro1);       //7
        System.out.println(nro1++);     //7
        System.out.println(nro1);       //8
        System.out.println(++nro1);     //9

        //TODO Tabla de verdad
        //TODO Operadores Relaciones
        //TODO Operadores Logicos

    }//end main
}//enc class Clase02