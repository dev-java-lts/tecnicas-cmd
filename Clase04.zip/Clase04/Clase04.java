public class Clase04 {
    public static void main(String[] args) {

        int nro = 4;
        boolean log1 = true;
        boolean tenerPlata = false;
        int plataCafe = 800;
        // Estructura condicional if
        if (!log1) {
            // indentado
            System.out.println("Verdad 1");
            System.out.println("xxxxxxxx");
        }

        if (tenerPlata) {
            System.out.println("Viajo a Europa!!!!");
        }

        if (plataCafe >= 400) {
            System.out.println("Tomamos Cafe!!!");
        }

        //Modo de llaves recomendado por Java
        if(tenerPlata==true){
            System.out.println("Viajo a Europa!!!!!");
        }

        //Modo de llaves abreviado
        if(log1) System.out.println("Verdad 2");

        //Modo de llaves expandido (Microsoft)
        if(log1)
        {
            System.out.println("Verdad 3");
        }

        //Estructura IF ELSE
        if(!log1){
            System.out.println("Verdad 4");
        }else{
            System.out.println("Falso 4");
        }

        //Modo Abreviado
        if(log1)    System.out.println("Verdad 5");
        else        System.out.println("Falso 5");

        //Modo Expandido
        if(log1)
        {
            System.out.println("Verdad 5");
        }
        else
        {
            System.out.println("Falso 6");
        }



    }
}
