public class Clase06{
    public static void main(String[] args) {
        
        //Estructura while

        int i=1;
        System.out.println("-- Inicio Estructura While --");
        while(i<=10){
            System.out.println(i);
            i++;
        }
        System.out.println("-- Fin Estructura While --");
        System.out.println(i);  //11
        
        //Uso de llaves Expandido recomendado por microsoft
        i=1;
        while(i<=10)
        {
            System.out.println(i);
            i++;
        }

        //Modo de llaves abreviado
        i=1;
        while(i<=10) System.out.println(i++);

        //Loop Infinito
        // i=1;
        // while(true){
        //     System.out.println(i);
        //     i++;
        // }

        //Loop Infinito
        // i=1;
        // while(i<=10 || true){
        //     System.out.println(i);
        //     i++;
        // }

        //Loop Infinito
        // i=1;
        // while(i<=10 || i>=1){
        //     System.out.println(i);
        //     i++;
        // }

        //Loop Infinito
        // i=1;
        // while(1<=10){
        //     System.out.println(i);
        //     i++;
        // }

        //Loop Infinito
        // i=1;
        // while(i<=10){
        //     System.out.println(i--);
        //     i++;
        // }

        //Loop Infinito
        // i=1;
        // while(i<=10);
        // {
        //     System.out.println(i);
        //     i++;
        // }

        i=20;
        System.out.println("-- Inicio Estructura While --");
        while(i<=10){
            System.out.println(i);
            i++;
        }
        System.out.println("-- Fin Estructura While --");
        System.out.println(i);  //20
        
        //Estructura Do While
        i=20;
        System.out.println("-- Inicio Estructura Do While --");
        do{
            System.out.println(i);
            i++;
        }while(i<=10);
        System.out.println("-- Fin Estructura Do While --");
        System.out.println(i);  //21


        //TODO Hacer ejercicios estructura condicional

        //TODO Hacer ejercicios estructura while


    }
}