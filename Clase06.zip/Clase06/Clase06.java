public class Clase06{
    public static void main(String[] args) {
        
        //Estructura while

        int i=1;
        System.out.println("-- Inicio Estructura While --");
        while(i<=10){
            System.out.println(i);
            i++;
        }
        System.out.println("-- Fin Estructura While --");
        System.out.println(i);  //11

        // TODO Terminar estructura while
        

    }
}