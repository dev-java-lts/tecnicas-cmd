public class Ejercicio3 {
    public static void main(String[] args) {
        System.out.println("A");
        int x = 10;
        int y = 20;
        System.out.println(x);              //10
        System.out.println(y);              //20
        System.out.println("B");
        x = x + y;
        y = y + x;
        System.out.println(x);              //30
        System.out.println(y);              //50
        System.out.println("C");
        x = x - y;
        y = y - x;
        System.out.println(x);              //-20        
        System.out.println(y);              //70
        System.out.println("D");
        x = x * y;
        y = x * x;
        System.out.println(x);              //-1400           
        System.out.println(y);              //1960000       
        System.out.println("E");        
        x = y / x;
        y = x / y;
        System.out.println(x);              //-1400        
        System.out.println(y);              //−0,000714286

        /*
         * 
         * Letra        X           Y
         * A            10          20
         * B            30          50
         * C            -20         70
         * D            -1400       1960000
         * E 
         */
    }
}
