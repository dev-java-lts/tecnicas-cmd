import java.util.Scanner;

public class Homero {
    public static void main(String[] args) {
        

        //System.out.println("Homero llevame a monte Splash? (S o N)");  
        //String respuesta=new Scanner(System.in).nextLine();
        //if(!respuesta.equalsIgnoreCase("s")) return;
        //return significa terminar el programa

        String respuesta;
        boolean irAMonteSplash=false;
        while(!irAMonteSplash){
            System.out.println("Homero llevame a monte Splash? (S o N)"); 
            respuesta=new Scanner(System.in).nextLine();
            if(respuesta.equalsIgnoreCase("s")) irAMonteSplash=true;
        }

        //versión Mariano
        // String respuesta;
        // boolean irAMonteSplash=false;
        // int intentos=0;
        // while((!irAMonteSplash) && intentos<10){
        //     System.out.println("Homero llevame a monte Splash? (S o N)"); 
        //     respuesta=new Scanner(System.in).nextLine();
        //     if(respuesta.equalsIgnoreCase("s")) irAMonteSplash=true;
        //     intentos++;
        // }

        System.out.println(Colores.ANSI_YELLOW);
        System.out.println("Vamos a monte Splash");
        System.out.println("""
            ______________________¶¶
            ______________________¶¶¶
            ______________________¶
            ______________________¶
            ___________¶¶¶________¶__________¶¶
            ___________¶¶¶¶¶_____¶¶¶_________¶¶¶¶
            ___________¶_________¶_¶_________¶
            ___________¶_________¶_¶_________¶¶
            ___________¶¶________¶_¶_________¶¶
            __________¶¶¶_______¶¶¶¶¶________¶¶
            __________¶_¶_______¶___¶_______¶_¶
            __________¶_¶_______¶___¶_______¶_¶
            __________¶_¶_______¶___¶_______¶__¶
            _________¶¶¶¶¶______¶_¶_¶______¶¶¶¶¶¶
            _________¶___¶______¶___¶______¶____¶
            _________¶¶¶¶¶______¶___¶______¶¶¶¶¶¶
            _________¶___¶______¶___¶_______¶__¶
            _________¶___¶______¶___¶______¶___¶
            _________¶___¶¶_¶¶_¶¶___¶_¶¶__¶¶___¶
            _________¶___¶¶¶¶¶¶¶¶___¶¶¶¶¶¶¶¶___¶
            _________¶___¶______¶___¶______¶___¶
            _________¶___¶______¶___¶______¶___¶
            _________¶___¶______¶___¶______¶___¶
            _________¶___¶______¶___¶______¶___¶
            _________¶___¶___¶¶¶¶¶¶¶¶¶¶¶___¶___¶
            _________¶___¶___¶_________¶___¶___¶
            _________¶___¶___¶_________¶¶__¶___¶
            _________¶___¶___¶______¶___¶__¶___¶
            _________¶___¶__¶¶¶¶¶____¶¶¶¶__¶___¶
            _________¶___¶__¶__¶_____¶__¶__¶___¶
            _________¶___¶__¶__¶_____¶__¶__¶___¶
            _________¶___¶__¶__¶_____¶__¶__¶___¶
            ____¶¶¶¶¶¶¶¶¶¶¶¶¶__¶¶_¶_¶¶__¶¶¶¶¶¶¶¶¶¶¶¶¶
            ____¶¶__________¶__¶¶¶¶¶¶¶__¶___________¶
            ____¶¶_¶__¶¶__¶_¶__¶¶¶¶¶¶¶__¶_¶¶__¶__¶¶_¶
            ____¶¶_¶__¶¶__¶_¶__¶¶¶¶¶¶¶__¶_¶¶__¶__¶¶_¶
            ____¶¶__________¶__¶¶¶¶¶¶¶__¶___________¶
            ____¶¶__________¶__¶¶¶¶¶¶¶__¶___________¶
            ____¶¶__________¶__¶¶¶¶¶¶¶__¶___________¶
            ____¶¶__________¶__¶¶¶¶¶¶¶__¶___________¶
            ____¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶
                """);
            System.out.println(Colores.ANSI_RESET);
    }
}
