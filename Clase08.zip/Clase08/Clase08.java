import java.text.DecimalFormat;
import java.time.LocalTime;

public class Clase08{
    public static void main(String[] args) {
        //Utilidad DecimalFormat
        DecimalFormat df=new DecimalFormat("$ ###,###.00");
        double valor=2000000.087373;
        System.out.println(valor);
        System.out.println(df.format(valor));
        valor=Math.PI;
        System.out.println(df.format(valor));

        DecimalFormat df2=new DecimalFormat("000000000");
        for(int a=0;a<=20; a++){
            System.out.println(df2.format(a));
        }

        //Recorrido for con variables globales
        int x;
        System.out.println("**************************************");
        for(x=1;x<=10;x++){
            System.out.println(x);
        }
        System.out.println("**************************************");
        System.out.println(x);      //11
        System.out.println("**************************************");
        for(x++;x<=20;x++){
            System.out.println(x);
        }
        System.out.println("**************************************");
        for(;x<=30;x++){
            System.out.println(x);
        }
        System.out.println("**************************************");

        //Omisión de parámetros
        x=1;
        for(;;){
            System.out.println(x);
            if(x>=10) break;         //rompe el ciclo for
            x++;
        }

        //Sentencias break y continue
        System.out.println("**************************************");
        for(int a=1; a<=20; a++){
            if(a==5 || a==10) continue;
            System.out.println(a);
            if(a==15)break;                 //rompe el ciclo for
        }
        System.out.println("**************************************");
        for(int a=1; a<=15; a++){
            if(a!=5 && a!=10) System.out.println(a);
        }
        System.out.println("**************************************");
        
        //Recorrido con varias variables de control
        for(int r=1, s=1 ; r <= 5 && s <=10 ; r ++ , s ++) {
            System.out.println(r+" "+s);
        }

        System.out.println("**************************************");

        for(int r=1, s=1 ; r <= 5 || s <=10 ; r ++ , s ++) {
            System.out.println(r+" "+s);
        }

        System.out.println("**************************************");

        //For anidado
        int cont=0;
        for(int r=1; r<=10; r++){
            for(int s=1; s<=10; s++){
                for(int t=1; t<=10; t++){
                    cont++;
                    System.out.println(r+" "+s+" "+t+" "+cont);    
                }
            }
        }
        DecimalFormat hs = new DecimalFormat("00");
        //Horas del reloj
        // for(int hora=0; hora<24; hora++){
        //     for(int minuto=0; minuto<60; minuto++){
        //         for(int segundo=0; segundo<60; segundo++){
        //             System.out.println(
        //                 hs.format(hora)+":"+
        //                 hs.format(minuto)+":"+
        //                 hs.format(segundo));
        //         }
        //     }
        // }
       
        // for(int hora=LocalTime.now().getHour(); hora<24; hora++){
        //     for(int minuto=LocalTime.now().getMinute(); minuto<60; minuto++){
        //         for(int segundo=LocalTime.now().getSecond(); segundo<60; segundo++){
        //             System.out.println(
        //                 hs.format(hora)+":"+
        //                 hs.format(minuto)+":"+
        //                 hs.format(segundo));
        //             try { Thread.sleep(1000); } catch(Exception e) {}
        //         }
        //     }
        // }

        //Loop Infinito
        // for(int i=1; true; i++){
        //     System.out.println(i);
        // }

        //Loop Infinito
        //for(int i=1; ; i++){
        //    System.out.println(i);
            //if(i>10) break;
        //}

        //Loop Infinito
        //for(int i=1; i<=10 || true; i++){
        //    System.out.println(i);
        //}

        //Loop Infinito
        // for(int i=1; i<=10 || i>=0; i++){
        //     System.out.println(i);
        // }

        //Loop Infinito
        // for(int i=1; i<=10; i++){
        //     System.out.println(i--);
        // }

        //Loop Infinito
        // for(int i=1; i<=10; ){
        //     System.out.println(i);
        // }

        //Loop Infinito
        // int a=3;
        // for(int i=a; a<=10; i++){
        //     System.out.println(i);
        // }

        //Loop Infinito
        // int a=3;
        // for(int i=a; i<=10; a++){
        //      System.out.println(i);
        // }

        
        // Laboratorio 4 Estructura FOR
        
        // Ejercicio 1
        // Imprimir los números del 1 al 10 uno abajo del otro.
        System.out.println("-- Ejercicio 1 --");
        for(int a=1; a<=10; a++) System.out.println(a);

        // Ejercicio 2
        // Imprimir los números del 1 al 10 salteando de a dos uno abajo del otro.
        System.out.println("-- Ejercicio 2 --");
        for(int a=1; a<=10; a+=2) System.out.println(a);

        // Ejercicio 3
        // Imprimir los números del 10 al 1 uno abajo del otro.
        System.out.println("-- Ejercicio 3 --");
        for(int a=10; a>=1; a--) System.out.println(a);

        // Ejercicio 4
        // Imprimir la suma de los números impares del 1 al 10.
        System.out.println("-- Ejercicio 4 --");
        int total=0;
        // for(int a=1; a<=10; a+=2){
        //     total+=a;
        // }
        for(int a=1; a<=10; a++){
            if(a%2!=0) total+=a; 
        }
        System.out.println("Total: "+total);
        // Ejercicio 5
        // Mostrar 
        //la suma de 
        //la multiplicación de los números del 1 al 5 
        //con 
        //la suma de los números del 1 al 5.
        System.out.println("-- Ejercicio 5 --");
        int multi=1;
        int suma=0;
        for(int a=1; a<=5; a++){
            multi*=a;
            suma+=a;
        }
        System.out.println("Total: "+(multi+suma));

        //Opción B      (Alejandro)
        System.out.println("*****ejer5*****");
        int prod = 1;
        int sum = 0;
        for (int i = 1; i <= 5; i++) {
            prod *= i;
            sum += prod;
            
        }
        System.out.println(sum);

        // Ejercicio 6
        // Imprimir la siguiente figura utilizando la estructura for:
        // @
        // @
        // @
        // @
        System.out.println("-- Ejercicio 6 --");
        // System.out.println("@");
        // System.out.println("@");
        // System.out.println("@");
        // System.out.println("@");
        // System.out.println("@");

        for(int a=1; a<=5; a++){
            System.out.println("@");
        }

        // Bonus Track 1
        // @@@@@
        System.out.println("-- Bonus Track 1--");
        for(int u=1; u<=5; u++){
            System.out.print("@");
        }
        System.out.println();

        // Ejercicio 7
        // Imprimir la siguiente figura utilizando la estructura for:
        // @
        // @@
        // @
        // @@
        // @
        System.out.println("-- Ejercicio 7 --");
        for(int a=1; a<=5; a++){
            if(a%2==0)  System.out.println("@@");
            else        System.out.println("@");
        }

        //Bonus Track 2
        // @@@@@
        // @@@@@
        // @@@@@
        // @@@@@
        // @@@@@
        System.out.println("-- Bonus Track 2");
        for(int y=1; y<=5; y++){
            for(int u=1; u<=5; u++){
                System.out.print("@");
            }
            System.out.println();
        }

        // Ejercicio 8
        // Imprimir la siguiente figura utilizando la estructura for:
        // @
        // @@
        // @@@
        // @@@@
        // @@@@@
        System.out.println("Ejercicio 8");
        for(int y=1; y<=5; y++){
            for(int u=1; u<=y; u++){
                System.out.print("@");
            }
            System.out.println();
        }

        //Versión Daniel
        // for (int n = 1; n <= 5; n++) {
        // 	String arr = new String(new char[n]).replace("\0", "@");
        // 	System.out.println(arr);
        // }

        //Versión Alejandro
        // System.out.println("*****ejer8*****");
        // for (int i = 1; i <= 5; i++) {
        //     for (int j = 0; j < i; j++) {
        //         System.out.print("@");
        //     }System.out.println("");
        // }

        // Ejercicio 9
        // Imprimir la siguiente figura utilizando la estructura for:
        // @@@@@
        // @@@@
        // @@@
        // @@
        // @
        System.out.println("-- Ejercicio 9 --");
        for(int y=5; y>=1; y--){
            for(int u=1; u<=y; u++){
                System.out.print("@");
            }
            System.out.println();
        }

        // Ejercicio 10
        // Imprimir la siguiente figura utilizando la estructura for:
        // @
        // @@
        // @@@
        // @@@@
        // @@@
        // @@
        // @
        System.out.println("-- Ejercicio 10 --");
        for(int y=1; y<=4; y++){
            for(int u=1; u<=y; u++){
                System.out.print("@");
            }
            System.out.println();
        }
        for(int y=3; y>=1; y--){
            for(int u=1; u<=y; u++){
                System.out.print("@");
            }
            System.out.println();
        }
        // Ejercicio 11
        // Imprimir la siguiente figura utilizando la estructura for:
        // @@@@@
        // @@@
        // @
        // @@@
        // @@@@@
        System.out.println("-- Ejercicio 11 --");
        for(int y=5; y>=1; y-=2){
            for(int u=1; u<=y; u++){
                System.out.print("@");
            }
            System.out.println();
        }
        for(int y=3; y<=5; y+=2){
            for(int u=1; u<=y; u++){
                System.out.print("@");
            }
            System.out.println();
        }

        //Versión Daniel
        int b = 7;
        for (int n = 1; n <= 5; n++) {
            if (n <= 3) {
                b -= 2;
            } else if (n > 3) {
                b += 2;
            }
            for (int c = 1; c <= b; c++) {
                System.out.print("@");
            }
            System.out.println("");
        }

        //TODO utilidades de JAVA
        //TODO Arrays
        //TODO Funciones

    }
}