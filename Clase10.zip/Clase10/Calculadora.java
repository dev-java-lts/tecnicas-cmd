import java.util.Scanner;

public class Calculadora {
    public static void main(String[] args) {
        /*
         * 
         * Se debe ingresar 3 parámetros por consola o linea de argumentos
         * 
         * Parámetro 1: String con el tipo de operación ('sumar', 'restar', 'multiplicar', 'dividir')
         * Parámetro 2: primer termino númerico
         * Parámetro 3: segundo termino númerico
         * 
         * Imprimir el resultado de la operación correspondiente.
         * 
         */

        String operacion="";
        double numero1=0;
        double numero2=0;
        if(args.length!=3){
            System.out.println("Ingrese la operación ('sumar', 'restar', 'multiplicar', 'dividir'): ");
            operacion=new Scanner(System.in).nextLine();
            System.out.println("Ingrese el número 1: ");
            numero1=new Scanner(System.in).nextInt();
            System.out.println("Ingrese el número 2: ");
            numero2=new Scanner(System.in).nextInt();
        }else{
            operacion=args[0];
            numero1=Integer.parseInt(args[1]);
            numero2=Integer.parseInt(args[2]);
        }

        switch(operacion){
            case "sumar":       System.out.println("Resultado: "+(numero1+numero2)); break;
            case "restar":      System.out.println("Resultado: "+(numero1-numero2)); break;
            case "multiplicar": System.out.println("Resultado: "+(numero1*numero2)); break;
            case "divivir":
                if(numero2==0){
                    System.out.println(Colores.ANSI_RED+"Error! "+Colores.ANSI_RESET+"no se puede dividir /0");
                } else {
                    System.out.println("Resultado: "+(numero1/numero2));
                }  
                break;
            default: System.out.println(Colores.ANSI_RED+"Error! "+Colores.ANSI_RESET+"en el ingreso de datos!");
        }

    }
}
