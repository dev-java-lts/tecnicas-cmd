public class Circulo {
    
    public static void main(String[] args) {
        
        //Replicar lo mismo con un circulo, (Perimetro y Superficie)
        // debe ingresar el radio, crear archivo Circulo.java

        //double pi=(double)Math.round(Math.PI*100)/100;
        //System.out.println(pi);

        System.out.println("Ingrese el radio: ");
        //int radio=new java.util.Scanner(System.in).nextInt();
        double radio = new java.util.Scanner(System.in).nextDouble();
        
        //double area=Math.PI*(radio*radio);
        //double perimetro=Math.PI*radio*2;

        //double area=(int)Math.PI*(radio*radio);
        //double perimetro=(int)Math.PI*radio*2;
    
        //double area=Math.round(Math.PI*(radio*radio));
        //double perimetro=Math.round(Math.PI*radio*2);

        double area=(double)Math.round(Math.PI*(radio*radio)*100)/100;
        double perimetro=(double)Math.round(Math.PI*radio*2*100)/100;

        System.out.println("Perimetro= "+perimetro);
        System.out.println("Area= "+area);


    }
}



