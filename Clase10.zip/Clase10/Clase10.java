import java.util.Scanner;

public class Clase10{
    public static void main(String[] args) {
        
        // Ejercicio 3
        // Se pide que ingrese por consola dos letras y realice
        // la siguiente operación:
        // 1. Mostrar la representación ASCII de las letras en
        // minúsculas y mayúsculas.
        /*
        System.out.println("-- Ejercici 3 --");
        System.out.println("Ingrese dos letras. ");
        System.out.print("Ingrese la letra 1: ");
        String letra1=new Scanner(System.in).nextLine();
        System.out.print("Ingrese la letra 2: ");
        String letra2=new Scanner(System.in).nextLine();
        if(letra1.length()!=1 || letra2.length()!=1){
            //error de ingreso
            System.out.println(Colores.ANSI_RED+"Error!!!"
                +Colores.ANSI_RESET+" Solo debe ingresar una sola letra!");
        }else{
            
            //letra 1
            int carLetra1=letra1.charAt(0);
            if(carLetra1>=65 && carLetra1<=90){
                //letra 1 mayúscula
                System.out.println(carLetra1+" "+(carLetra1+32));
            }else{
                //letra 1 minúscula
                System.out.println((carLetra1-32)+" "+carLetra1);
            }

            //letra 2
            int carLetra2=letra2.charAt(0);
            if(carLetra2>=65 && carLetra2<=90){
                //letra 2 mayúscula
                System.out.println(carLetra2+" "+(carLetra2+32));
            }else{
                //letra 2 minúscula
                System.out.println((carLetra2-32)+" "+carLetra2);
            }

        }
        */

        //Arrays - Vectores
        int[] numeros=new int[4];
        String[] nombres=new String[4];
        numeros[0]=1;
        nombres[0]="Juan";
        numeros[1]=2;
        nombres[1]="Jose";
        numeros[2]=3;
        nombres[2]="Maria";
        numeros[3]=4;
        nombres[3]="Javier";
        //numeros[4]=4;
        //nombres[4]="Karina";


        /*
         *      numeros         nombres                     indices
         *          1           Juan                            0
         *          2           Jose                            1
         *          3           Maria                           2
         *          4           Javier                          3
         */

        System.out.println(numeros[2]+" "+nombres[2]);
        //System.out.println(numeros[4]+" "+nombres[4]);

        System.out.println("***************************************");
        //System.out.println(numeros[0]+" "+nombres[0]);
        //System.out.println(numeros[1]+" "+nombres[1]);
        //System.out.println(numeros[2]+" "+nombres[2]);
        //System.out.println(numeros[3]+" "+nombres[3]);

        //Recorrido de vector
        for(int a=0; a<4; a++){
            System.out.println(numeros[a]+" "+nombres[a]);
        }

        //método length
        System.out.println("longitud vector numeros: "+numeros.length);

        //String texto="hola";

        //Recorrido de vector usando método length
        for(int a=0; a<numeros.length;a++){
            System.out.println(numeros[a]+" "+nombres[a]);
        }

        //recorrido usando while
        System.out.println("*****************************");
        int x=0;
        while(x<numeros.length){
            System.out.println(numeros[x]+" "+nombres[x]);
            x++;
        }

        //recorrido inverso
        System.out.println("*************************");
        for(int a=numeros.length-1; a>=0; a--){
            System.out.println(numeros[a]+" "+nombres[a]);
        }


        
    }
}