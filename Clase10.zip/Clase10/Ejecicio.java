public class Ejecicio {
    public static void main(String[] args) {
        //TODO Pendiente
        /*
         * 
         * Ingresar por consola o por vector de argumentos 10 notas de un alumno
         * - Informar promedio de notas con 2 decimales
         * - Informar nota máxima y nota mínima
         * - Si el promedio es >=7 informar 'Aprobado' sino 'Desaprobado'
         * 
         */
    }
}
