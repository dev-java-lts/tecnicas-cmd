public class EjemploArgumentos {
    public static void main(String[] args) {
        System.out.println("longitud args: "+args.length);
        for(int a=0; a<args.length; a++){
            System.out.println(args[a]);
        }
    }
}
