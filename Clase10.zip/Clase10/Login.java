public class Login {
    public static void main(String[] args) {
        /*
         * Ingresar por consola nombre de usuario y clave.
         * Si el usuario es 'root' y la clave es '123' informar 
         *              'Bienvenido al Sistema'
         * Si el usuario es 'root' y la clave no es '123' informar 
         *              'Clave Incorrecta'
         * Si el usuario no es 'root' informar 'Usuario Incorrecto'
         * 
         */

        System.out.println(Colores.ANSI_GREEN);
        System.out.println("*******************************************************");
        System.out.println("*               LOGIN DE USUARIOS                     *");
        System.out.println("*******************************************************");
        Ahora.main(null);
        System.out.println(Colores.ANSI_BLUE);
        System.out.print("Ingrese su nombre de usuario: ");
        String usuario=new java.util.Scanner(System.in).nextLine();
        System.out.print("Ingrese su clave: ");
        String clave=new java.util.Scanner(System.in).nextLine();
        
        System.out.println(Colores.ANSI_RED);
        System.out.println("""
            ░░░░░░░░░░░░░░░░░░░░░░█████████
            ░░███████░░░░░░░░░░███▒▒▒▒▒▒▒▒███
            ░░█▒▒▒▒▒▒█░░░░░░░███▒▒▒▒▒▒▒▒▒▒▒▒▒███
            ░░░█▒▒▒▒▒▒█░░░░██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒██
            ░░░░█▒▒▒▒▒█░░░██▒▒▒▒▒██▒▒▒▒▒▒██▒▒▒▒▒███
            ░░░░░█▒▒▒█░░░█▒▒▒▒▒▒████▒▒▒▒████▒▒▒▒▒▒██
            ░░░█████████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒██
            ░░░█▒▒▒▒▒▒▒▒▒▒▒▒█▒▒▒▒▒▒▒▒▒█▒▒▒▒▒▒▒▒▒▒▒██
            ░██▒▒▒▒▒▒▒▒▒▒▒▒▒█▒▒▒██▒▒▒▒▒▒▒▒▒▒██▒▒▒▒██
            ██▒▒▒███████████▒▒▒▒▒██▒▒▒▒▒▒▒▒██▒▒▒▒▒██
            █▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒█▒▒▒▒▒▒████████▒▒▒▒▒▒▒██
            ██▒▒▒▒▒▒▒▒▒▒▒▒▒▒█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒██
            ░█▒▒▒███████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒██
            ░██▒▒▒▒▒▒▒▒▒▒████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒█
            ░░████████████░░░█████████████████
        """);
        //System.out.println(usuario+" "+clave);
        //System.out.println(usuario=="root");        
        //System.out.println(usuario.equals("root"));
        /*
        if(usuario.equals("root")){
            if(clave.equals("123")){
                System.out.println(Colores.ANSI_GREEN+"Bienvenido Usuario!");
            }else{
                System.out.println(Colores.ANSI_RED+"Clave Incorrecta!");
            }
        }else{
            System.out.println(Colores.ANSI_RED+"Usuario Incorrecto!!");
        }
        */
        //https://codeshare.io/Wd6xnl
        //Refactorizar

        if(usuario.equals("root") && clave.equals("123"))  System.out.println(Colores.ANSI_GREEN+"Bienvenido al Sistema!");
        //else System.out.println(Colores.ANSI_RED+"Usuario o Clave Incorrectas");
        if(usuario.equals("root") && !clave.equals("123")) System.out.println(Colores.ANSI_RED+"Clave Incorrecta!");
        if(!usuario.equals("root"))                                  System.out.println(Colores.ANSI_RED+"Usuario Incorrecto!");
        System.out.println(Colores.ANSI_RESET);

    }
}
