public class Rectangulo {
    public static void main(String[] args) {
        /*
         * - Ingresar por consola la longitud de dos lados de un rectangulo.
         * - Calcular e imprimir el perimetro y superficie del rectangulo.
         */

        int lado1=0;
        int lado2=0;

        if(args.length!=2){
            System.out.println("Ingrese el lado 1: ");
            lado1=new java.util.Scanner(System.in).nextInt();
            System.out.println("Ingrese el lado 2: ");
            lado2=new java.util.Scanner(System.in).nextInt();
        } else {
            lado1=Integer.parseInt(args[0]);
            lado2=Integer.parseInt(args[1]);
        }
        double perimetro=(lado1+lado2)*2;
        double superficie=lado1*lado2;

        System.out.println("Perimetro= "+perimetro);
        System.out.println("Superficie= "+superficie);

        //TODO Replicar lo mismo con un triangulo rectangulo,
        // debe ingresar base y altura


    }
}
