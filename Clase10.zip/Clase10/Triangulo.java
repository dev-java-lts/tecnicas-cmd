public class Triangulo{
    public static void main(String[] args) {

        //https://codeshare.io/3AKLAL

        //Replicar lo mismo con un triangulo rectangulo,
        // debe ingresar base y altura
        //System.out.println(Math.sqrt(4));       //2
        //System.out.println(Math.sqrt(16));      //4
        //System.out.println(Math.pow(2, 4));     //16  
        
        //int valor=4;
        //System.out.println(Math.pow(4, 2));     //16
        //System.out.println(valor*valor);             //16

        int base=0;
        int altura=0;

        if(args.length!=2){
            System.out.println("Ingrese la base del triangulo: ");
            base=new java.util.Scanner(System.in).nextInt();

            System.out.println("Ingrese la altura del triangulo: ");
            altura=new java.util.Scanner(System.in).nextInt();
        }else{
            base=Integer.parseInt(args[0]);
            altura=Integer.parseInt(args[1]);
        }


        int superficie=(base*altura)/2;
        //int perimetro=base+altura+(int)Math.sqrt((base*base)+(altura*altura));
        int perimetro=  base+
                        altura+
                        //(int)Math.sqrt(Math.pow(base,2)+Math.pow(altura, 2));
                        (int)Math.hypot(base, altura);

        System.out.println("Superficie: "+superficie);
        System.out.println("Perimetro: "+perimetro);

        
        //Replicar lo mismo con un circulo, (Perimetro y Superficie)
        // debe ingresar el radio, crear archivo Circulo.java
        


    }
}