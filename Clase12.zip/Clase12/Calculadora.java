import java.util.Scanner;

public class Calculadora {
    public static void main(String[] args) {
        /*
         * 
         * Se debe ingresar 3 parámetros por consola o linea de argumentos
         * 
         * Parámetro 1: String con el tipo de operación ('sumar', 'restar', 'multiplicar', 'dividir')
         * Parámetro 2: primer termino númerico
         * Parámetro 3: segundo termino númerico
         * 
         * Imprimir el resultado de la operación correspondiente.
         * 
         */

        String operacion="";
        double numero1=0;
        double numero2=0;
        if(args.length!=3){
            System.out.println("Ingrese la operación ('sumar', 'restar', 'multiplicar', 'dividir'): ");
            operacion=new Scanner(System.in).nextLine();
            System.out.println("Ingrese el número 1: ");
            numero1=new Scanner(System.in).nextInt();
            System.out.println("Ingrese el número 2: ");
            numero2=new Scanner(System.in).nextInt();
        }else{
            operacion=args[0];
            numero1=Integer.parseInt(args[1]);
            numero2=Integer.parseInt(args[2]);
        }

        switch(operacion){
            case "sumar":       sumar(numero1,numero2);       break;
            case "restar":      restar(numero1,numero2);      break;
            case "multiplicar": multiplicar(numero1,numero2); break;
            case "divivir":     dividir(numero1,numero2);     break;
            default: System.out.println(Colores.ANSI_RED+"Error! "+Colores.ANSI_RESET+"en el ingreso de datos!");
        }

    }

    public static void sumar(double nro1, double nro2){
        System.out.println(nro1+nro2);
    }

    public static void restar(double nro1, double nro2){
        System.out.println(nro1-nro2);
    }

    public static void multiplicar(double nro1, double nro2){
        System.out.println(nro1+nro2);
    }

    public static void dividir(double nro1, double nro2){
        if(nro2==0){
            System.out.println("Error División por 0");
        }else{
            System.out.println(nro1+nro2);
        }
    }
}
