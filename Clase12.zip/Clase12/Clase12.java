import javax.swing.JOptionPane;

public class Clase12{
    public static void main(String[] args) {
        
        //- Funciones 
        cartel();
        cartel();
        cartel();

        //- Funciones parámetricas
        cartel("*                 Curso de Java                       *"); 
        cartel("*         Feliz Día del Estudiante!!                  *"); 
        cartel("*             Feliz Primavera!!                       *"); 
        cartel("*             Feliz Primavera!!                       *",Colores.ANSI_CYAN); 
        cartel("*             Feliz Primavera!!                       *",Colores.ANSI_BLUE); 
        cartel("*             Feliz Primavera!!                       *",Colores.ANSI_PURPLE); 
        cartel("*             Feliz Primavera!!                       *",Colores.ANSI_RED); 
        cartel("*             Feliz Primavera!!                       *",Colores.ANSI_WHITE); 
        cartel("*             Feliz Primavera!!                       *",Colores.ANSI_YELLOW); 


        sumar(38,39);
        //- Funciones con devolución de valores
        System.out.println(sumar2(23,26));

        //JOptionPane.showMessageDialog(null, "Hola a todos!!");
        //JOptionPane.showMessageDialog(null, "Total: "+sumar2(29,65));

        cartel("*           RECREO HASTA 11:20hs                      *",Colores.ANSI_RED); 

    }

    //función con devolución de valores
    public static int sumar2(int nro1, int nro2){
        return nro1+nro2;
    }

    public static void sumar(int nro1, int nro2){
        System.out.println(nro1+nro2);
    }

    //declaración de una función
    public static void cartel(){
        System.out.println(Colores.ANSI_GREEN);
        System.out.println("*******************************************************");
        System.out.println("*      Centro de Formación Profesional N 35           *");
        System.out.println("*******************************************************");
        Ahora.main(null);
    }

    //Función parámetrica
    public static void cartel(String texto){
        System.out.println(Colores.ANSI_GREEN);
        System.out.println("*******************************************************");
        System.out.println(texto);
        System.out.println("*******************************************************");
        Ahora.main(null);
    }

    public static void cartel(String texto, String color){
        System.out.println(color);
        System.out.println("*******************************************************");
        System.out.println(texto);
        System.out.println("*******************************************************");
        Ahora.main(null);
    }

}