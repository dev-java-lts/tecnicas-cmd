import java.util.Arrays;
import java.util.Scanner;

//import java.util.*;

public class Ejercicio {
    static String[] lista;
    public static void main(String[] args) {
        
        /*
         * - Ingresa por consola de programa o sistema una lista de nombres de personas
         * - Informar cantidad de personas
         * - Informar la lista ordenada alfabeticamente
         * - Imprimir una persona random
         */

        cargarDatos(args);
    
        informar();

        ordenar();

        random();

        //random();


    }
    private static void random() {
        //- Imprimir una persona random
        System.out.println("Persona Random: "+lista[(int)(Math.random()*lista.length)]);
    }
    private static void ordenar() {
        //- Informar la lista ordenada alfabeticamente
        Arrays.sort(lista);
        for(int a=0; a<lista.length; a++){
            System.out.println(lista[a]);
        }
    }
    private static void informar() {
        //- Informar cantidad de personas
        System.out.println("Se ingresaron "+lista.length+" personas.");
    }
    private static void cargarDatos(String[] args) {
        // - Ingresa por consola de programa o sistema una lista de nombres de personas
        if(args.length==0){
            System.out.print("Ingrese la cantidad de personas: ");
            int cantidad=new Scanner(System.in).nextInt();
            lista=new String[cantidad];
            for(int a=0; a<cantidad; a++){
                System.out.print("Ingrese el nombre "+a+": ");
                lista[a]=new Scanner(System.in).nextLine();
            }
        }else{
            lista=args;
        }
    }
}
