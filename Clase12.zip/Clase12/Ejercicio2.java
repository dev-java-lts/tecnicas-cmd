public class Ejercicio2 {
    public static void main(String[] args) {
        //TODO Ejercicio
        /*
         * Ejercicio 
         * - Crear la funcion superficieRectangulo, ingresa como parámetros dos lados
         * y devuelve el calculo de superficie.
         * 
         * - Crear la funcion perimetroRectangulo, ingresa como parámetros dos lados
         * y devuelve el calculo devuelve el perimetro.
         * 
         */
    }
}
