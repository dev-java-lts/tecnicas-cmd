public class Login {
    static String[] usuarios=  {"Juan","Maria","Jose", "Ana"};
    static String[] claves=    {"123", "321",  "111",  "abc"};
    static String usuario;
    static String clave;
    public static void main(String[] args) {

        welcome();

        cargarDatos(args);

        login();

    }

    private static void login() {
        boolean existe=false;
        int donde=0;
        for(int a=0; a<usuarios.length; a++){
            if(usuario.equals(usuarios[a])){
                existe=true;
                donde=a;
                break;
            }
        }
        //System.out.println(existe+" "+donde);
        if(existe && clave.equals(claves[donde])){
            System.out.println(Colores.ANSI_GREEN+"Bienvenido al Sistema!");
            ingresoOK();
        }else{
            System.out.println(Colores.ANSI_RED+"Credenciales Incorrectas!");
            ingresoDenied();
        }
    }
    private static void ingresoOK() {
        System.out.println(Colores.ANSI_GREEN);
        System.out.println("""

            ░░░░░░░░░░░░░░░░░░░░░░░░░░█
            ░░░░░░░░░░░░░░░░░░░░░░░░█████
            ░░░░░░░░░░░░░░░░░░░░░░█████████
            ░░███████░░░░░░░░░░███▒▒▒▒▒▒▒▒███
            ░░█▒▒▒▒▒▒█░░░░░░░███▒▒▒▒▒▒▒▒▒▒▒▒▒███
            ░░░█▒▒▒▒▒▒█░░░░██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒██
            ░░░░█▒▒▒▒▒█░░░██▒▒▒▒▒██▒▒▒▒▒▒██▒▒▒▒▒███
            ░░░░░█▒▒▒█░░░█▒▒▒▒▒▒████▒▒▒▒████▒▒▒▒▒▒██
            ░░░█████████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒██
            ░░░█▒▒▒▒▒▒▒▒▒▒▒▒█▒▒▒▒▒▒▒▒▒█▒▒▒▒▒▒▒▒▒▒▒███
            ░██▒▒▒▒▒▒▒▒▒▒▒▒▒█▒▒▒██▒▒▒▒▒▒▒▒▒▒██▒▒▒▒███
            ██▒▒▒███████████▒▒▒▒▒██▒▒▒▒▒▒▒▒██▒▒▒▒▒██
            █▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒█▒▒▒▒▒▒████████▒▒▒▒▒▒▒██
            ██▒▒▒▒▒▒▒▒▒▒▒▒▒▒█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒██
            ░█▒▒▒███████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒██
            ░██▒▒▒▒▒▒▒▒▒▒████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒█
            ░░████████████░░░█████████████████
            ░░░██████████░░░░░██████████████
            ░░░░████████░░░░░░░████████████

        """);
    }
    private static void ingresoDenied() {
        System.out.println(Colores.ANSI_RED);
        System.out.println("""
            __________________10000000000011__________________
            _______________10000000000000000001_______________
            _____________00000000000000000000000______________
            ____________00000111000000001111100001____________
            __________10001_______10001_______10001___________
            _________1000__________11___________000___________
            _________0001_____101_______11______1000__________
            _________000______101_______11______1000__________
            ________10001___________1___________10001_________
            ________10000001_____1000001_____10000001_________
            _________0000000000000000000000000000000__________
            _________1000000000001______100000000000__________
            ___________0000001______________1000001___________
            ____________00000____10000001____00001____________
            _____________0000__100000000000_1001____111_______
            _____00000________11000000000001____1000000011____
            ____0000000000001______________100000000000001____
            ____000000000000000011_____110000111______________
            _________________0100000000000011__1______________
            ____0000000000000001___________110000000000000____
            ____00000000000011_________________110000000011___
            _____000000001_________________________1000001____
            _____100001_______________________________1001____  
        """);
    }
    private static void cargarDatos(String[] args) {
        if(args.length!=2){
            System.out.println(Colores.ANSI_BLUE);
            System.out.print("Ingrese su nombre de usuario: ");
            usuario=new java.util.Scanner(System.in).nextLine();
            System.out.print("Ingrese su clave: ");
            clave=new java.util.Scanner(System.in).nextLine();
        }else{
            usuario=args[0];
            clave=args[1];
        }
    }
    private static void welcome() {
        System.out.println(Colores.ANSI_GREEN);
        System.out.println("*******************************************************");
        System.out.println("*               LOGIN DE USUARIOS                     *");
        System.out.println("*******************************************************");
        Ahora.main(null);
    }
}
