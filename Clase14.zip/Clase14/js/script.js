
lightbox.option({
  'resizeDuration': 6000,
  'wrapAround': true

})
