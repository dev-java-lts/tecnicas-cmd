package com.example.tecnicas;

import java.time.LocalDate;
import java.util.Calendar;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class ControladorWeb {
    

    @GetMapping("/test")
    public String test(Model model){

        //fecha actual
        String fecha=LocalDate.now().toString();

        //permitir ver en la página el dato fecha
        model.addAttribute("fecha", fecha);

        //permite publicar la pagina test.html
        return "test";
    }

    @GetMapping("/sistema")
    public String sistema(Model model){

        String fecha=LocalDate.now().toString();
        String ubicacion=Calendar
                                .getInstance()
                                .getTimeZone()
                                .getID()
                                .replace("/", " ")
                                .replace("_", " ");
        String so=  System.getProperty("os.name")+" "+
                    System.getProperty("os.version")+" "+
                    System.getProperty("os.arch");
        String java=System.getProperty("java.vm.name")+" "+
                    System.getProperty("java.version");
        String usuario= System.getProperty("user.name")+" "+
                        System.getProperty("user.language");
        model.addAttribute("fecha", ubicacion+" "+fecha);       
        model.addAttribute("so", so);
        model.addAttribute("java", java);
        model.addAttribute("usuario", usuario);        
        return "sistema";
    }

    @GetMapping("/sumar")
    public String sumar(
        @RequestParam(name="numero1", required=false, defaultValue="0") int nro1,
        @RequestParam(name="numero2", required=false, defaultValue="0") int nro2,
        Model model){
        model.addAttribute("suma", nro1+nro2);
        return "sumar";
    }

}
