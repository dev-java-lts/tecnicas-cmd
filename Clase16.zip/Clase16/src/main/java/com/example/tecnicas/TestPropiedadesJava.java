package com.example.tecnicas;

public class TestPropiedadesJava {
    public static void main(String[] args) {
        System.out.println(System.getProperties());
        String[] propiedades=System.getProperties().toString().split(",");
        for(int a=0; a<propiedades.length; a++) System.out.println(propiedades[a]);
    }
}
