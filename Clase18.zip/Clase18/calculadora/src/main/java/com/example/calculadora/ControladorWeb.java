package com.example.calculadora;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class ControladorWeb {
    // instalar git bash https://git-scm.com/ 
    // cerrar visual-code al instalar
    // correr el server desde gitbash sh mvnw spring-boot:run 
    // localhost:8080/calculadora

    @GetMapping("/calculadora")
    public String calculadora(
        @RequestParam(name="numero1", required=true, defaultValue="0")double numero1,
        @RequestParam(name="numero2", required=true, defaultValue="0")double numero2,
        @RequestParam(name="operacion", required=true, defaultValue="sumar") String operacion,
        Model model
    ){
        model.addAttribute("resultado",operar(numero1, numero2, operacion));
        return "calculadora";
    }
     
    public static String operar(double nro1, double nro2, String operacion){
        switch(operacion){
            case "sumar":       return sumar(nro1,nro2)+"";
            case "restar":      return restar(nro1,nro2)+"";
            case "multiplicar": return multiplicar(nro1, nro2)+"";
            case "dividir":     
                                if(nro2==0) return "Error División /0";
                                else return dividir(nro1,nro2)+"";
            default: return "Operación incorrecta!";
        }
    }

    public static double sumar(double nro1, double nro2){
        return nro1+nro2;
    }
    public static double restar(double nro1, double nro2){
        return nro1-nro2;
    }
    public static double dividir(double nro1, double nro2){
        return nro1/nro2;
    }
    public static double multiplicar(double nro1, double nro2){
        return nro1*nro2;
    }
}
