public class Programa {
    public static void main(String[] args) {
        //método principal, punto de entrada del proyecto

        System.out.println("Inicio del programa!");

        System.out.println("-- auto1 --");
        Auto auto1=new Auto();  //construye un objeto de la clase Auto
        auto1.marca="Fiat";
        auto1.modelo="Toro";
        auto1.color="Rojo";
        auto1.acelerar();           //10
        auto1.acelerar();           //20
        auto1.acelerar();           //30
        auto1.frenar();             //20
        System.out.println(auto1.marca+" "+auto1.modelo+" "+auto1.color+" "+auto1.velocidad);
    
        //TODO parámetros de entrada y salida de métodos
    
    }
}
