
//Declaración de clase
public class Auto{

    //Atributos
    String marca;
    String modelo;
    String color;
    int velocidad;

    //Métodos
    public void acelerar(){                         //acelerar
        //velocidad=velocidad+10;
        //velocidad+=10; //esta hardcodeado una aceleración de 10 kms / hora
        //if(velocidad>100) velocidad=100;
        acelerar(10);   //llamado de método dentro de la misma clase
    }

    //Método con parámetro de entrada
    //Método sobrecargado.
    /**
     * Método para acelerar un auto
     * @param kilometros cantidad de kilometros a acelerar.
     */
    public void acelerar(int kilometros){           //acelerarInt
        velocidad+=kilometros;
        if(velocidad>100) velocidad=100;
    }

    public void acelerar(int kilometros, boolean nitro){ //acelerarIntBoolean
        if(nitro){
            acelerar(kilometros*2);     //llamado de método dentro de una misma clase
        }else{
            acelerar(kilometros);
        }
    }

    void frenar(){
        //velocidad=velocidad-10;
        velocidad-=10;
    }

    //método sin valor de retorno (void)
    public void imprimirVelocidad(){
        System.out.println(velocidad);
    }

    //método con retorno de valor
    public int obtenerVelocidad(){
        return velocidad;
    }


    public String toString(){
        return marca+", "+modelo+", "+color+", "+velocidad;
    }



    
    //todo asistencia
    //horario
    //github

}//end class