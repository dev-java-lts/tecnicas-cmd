public class Circulo {
    int radio;
    int calcularPerimetro(){
        return (int)(radio*Math.PI*2);
    }
    int calcularSuperficie(){
        return (int)(Math.PI*radio*radio);
    }
}
