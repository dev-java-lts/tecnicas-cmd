public class Cliente {
    int nro;
    String nombre;
    int edad;
    Cuenta cuenta;  //El cliente tiene una cuenta!!

    public String toString(){
        return nro+", "+nombre+", "+edad+", "+cuenta;
    }
}
