public class Cuenta {
    int nro;
    Moneda moneda;  // arg$, u$s, Reales
    double saldo;

    void depositar(double monto){
        saldo+=monto;
    }

    void debitar(double monto){
        if(monto>saldo){
            System.out.println("Saldo Insuficiente!!!");
        } else {
            saldo-=monto;
        }
    }

    public String toString(){
        return nro+", "+moneda+", "+saldo;
    }
}
