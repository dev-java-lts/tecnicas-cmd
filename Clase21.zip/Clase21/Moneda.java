public enum Moneda {
    args,
    uss,
    Reales
}
