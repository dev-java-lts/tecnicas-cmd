import javax.swing.JOptionPane;

public class Programa {
    public static void main(String[] args) {
        //método principal, punto de entrada del proyecto

        System.out.println("Inicio del programa!");

        System.out.println("-- auto1 --");
        Auto auto1=new Auto();  //construye un objeto de la clase Auto
        auto1.marca="Fiat";
        auto1.modelo="Toro";
        auto1.color="Rojo";
        auto1.acelerar();           //10
        auto1.acelerar();           //20
        auto1.acelerar();           //30
        auto1.frenar();             //20
        auto1.acelerar(15);         //35
        System.out.println(auto1.marca+" "+auto1.modelo+" "+auto1.color+" "+auto1.velocidad);
    
        System.out.println("-- auto2 --");
        Auto auto2=new Auto();
        auto2.marca="Ford";
        auto2.modelo="Ka";
        auto2.color="Azul";
        for(int a=0; a<=60; a++) auto2.acelerar();

        System.out.println(auto2.marca+" "+auto2.modelo+" "+auto2.color+" "+auto2.velocidad);
        
        auto2.imprimirVelocidad();
        System.out.println(auto2.obtenerVelocidad());

        //JOptionPane.showMessageDialog(null, "Hola a todos!!");
        //JOptionPane.showMessageDialog(null, "Velocidad: "+auto2.obtenerVelocidad());

        //Método toString()
        System.out.println(auto2.toString());
        System.out.println(auto2);
        System.out.println(auto1);

        System.out.println("-- cuenta1 --");
        Cuenta cuenta1=new Cuenta();
        cuenta1.nro=1;
        cuenta1.moneda=Moneda.args;
        cuenta1.depositar(50000);
        cuenta1.depositar(30000);
        cuenta1.debitar(40000);
        System.out.println(cuenta1);

        //TODO Terminar Ejercicio
        /*
         * Ejercicio: crear las clases 
         *          Triangulo atributos base y altura, 
         *          Rectangulo atributos lado1, lado2, 
         *          Circulo atributo radio,
         *  todas las clases tienen el metodo, calcularSuperficie y calcularPerimetro
         * 
         */

        System.out.println("Triangulo");
        Triangulo triangulo=new Triangulo();
        triangulo.base=40;
        triangulo.altura=50;
        System.out.println("Perimetro: "+triangulo.calcularPerimetro());
        System.out.println("Superficie: "+triangulo.calcularSuperficie());

        System.out.println("Rectangulo");
        Rectangulo rectangulo=new Rectangulo();
        rectangulo.lado1=40;
        rectangulo.lado2=50;
        System.out.println("Perimetro: "+rectangulo.calcularPerimetro());
        System.out.println("Superficie: "+rectangulo.calcularSuperficie());

        System.out.println("Circulo");
        Circulo circulo=new Circulo();
        circulo.radio=50;
        System.out.println("Perimetro: "+circulo.calcularPerimetro());
        System.out.println("Superficie: "+circulo.calcularSuperficie());

        print("2");
        print(2);
        print(2.0f);


        System.out.println("-- cliente1 --");
        Cliente cliente1=new Cliente();
        cliente1.nombre="Juan Perez";
        cliente1.edad=50;
        cliente1.nro=1;
        cliente1.cuenta=new Cuenta();
        cliente1.cuenta.nro=20;
        cliente1.cuenta.moneda=Moneda.args;
        cliente1.cuenta.depositar(50000);
        cliente1.cuenta.debitar(10000);
        System.out.println(cliente1);

      /*
       * Recreo hasta 11:00 hs
       * 
       * 
       * En un colegio existen alumnos (clase Alumno),
       * también existes computadoras (clase Computadora).
       * Durante la clase el Alumno tiene una computadora!!!
       * 
       */



       }

      static void print(String x){
        System.out.println("String");
      }
      static void print(int x){
        System.out.println("int");
      }
      static void print(float x){
        System.out.println("float");
      }
}
