<h1>Aviso Importante</h1>
<b>A partír de Jueves 27/10/2022 iniciamos las clases a las 9:30hs</b>