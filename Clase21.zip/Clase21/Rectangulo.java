public class Rectangulo{
    int lado1;
    int lado2;
    int calcularPerimetro(){
        return (lado1+lado2)*2;
    }
    int calcularSuperficie(){
        return lado1*lado2;
    }
}
