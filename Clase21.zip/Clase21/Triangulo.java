public class Triangulo {
    int base;
    int altura;
    int calcularPerimetro(){
        return (int)(base+altura+Math.hypot(base, altura));
    }
    int calcularSuperficie(){
        return base*altura/2;
    }
}
