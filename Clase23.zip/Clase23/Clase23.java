public class Clase23{
    public static void main(String[] args) {
        System.out.println("-- Clase23 --");

        System.out.println("-- cuenta1 --");
        Cuenta cuenta1=new Cuenta(1, "args");
        cuenta1.depositar(80000);
        cuenta1.depositar(70000);
        cuenta1.debitar(30000);
        System.out.println(cuenta1);

        System.out.println("-- cliente1 --");
        Cliente cliente1=new Cliente(
                                    1,                                  //nro
                                    "Anabella",                      //nombre
                                    "Carrera",                     //apellido
                                    34,                                //edad
                                    new Cuenta(2,"arg$")        //cuenta
                        );
        cliente1.cuenta.depositar(450000);
        cliente1.cuenta.depositar(180000);
        cliente1.cuenta.debitar(40000);
                                
        System.out.println(cliente1);

    }
}