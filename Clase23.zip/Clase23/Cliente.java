public class Cliente {
    int nro;
    String nombre;
    String apellido;
    int edad;
    Cuenta cuenta;

    //método constructor
    Cliente(int nro, String nombre, String apellido, int edad, Cuenta cuenta){
        this.nro=nro;
        this.nombre=nombre;
        this.apellido=apellido;
        this.edad=edad;
        this.cuenta=cuenta;
    }

    public String toString(){
        return nro+", "+nombre+", "+apellido+", "+edad+", "+cuenta;
    }

}
