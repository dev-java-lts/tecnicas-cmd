public class Cuenta {
    int nro;
    String moneda;
    double saldo;

    //método constructor
    Cuenta(int nro, String moneda){
        this.nro=nro;
        this.moneda=moneda;
    }

    void depositar(double monto){
        saldo+=monto;
    }

    void debitar(double monto){
        if(saldo>=monto){
            saldo-=monto;
        }else{
            System.out.println("Saldo Insuficiente!!");
        }
    }

    public String toString(){
        return this.nro+", "+this.moneda+", "+this.saldo;
    }
    
}
