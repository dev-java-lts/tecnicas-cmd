public class Alumno {
    
    private int nroAlumno;
    private String nombre;
    private String apellido;
    private Curso curso;
    
    public Alumno(int nroAlumno, String nombre, String apellido, Curso curso) {
        this.nroAlumno = nroAlumno;
        this.nombre = nombre;
        this.apellido = apellido;
        this.curso = curso;
    }

    @Override
    public String toString() {
        return "Alumno [nroAlumno=" + nroAlumno + ", nombre=" + nombre + ", apellido=" + apellido + ", curso=" + curso
                + "]";
    }

    public int getNroAlumno() {
        return nroAlumno;
    }

    public void setNroAlumno(int nroAlumno) {
        this.nroAlumno = nroAlumno;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public Curso getCurso() {
        return curso;
    }

    public void setCurso(Curso curso) {
        this.curso = curso;
    }

}
