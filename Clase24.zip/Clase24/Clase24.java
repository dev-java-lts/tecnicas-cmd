public class Clase24{
    public static void main(String[] args) {
        /*
         * Clase Profesor, atributos nroLEgajo, nombre, apellido, titulo
         * Clase Curso, atributos nroCurso, titulo, profesor, dia, turno
         * Clase Alumno, atributos nroAlumno, nombre, apellido, curso.
         * 
         * //enums revisar moneda clase20
         * Dia enum LUNES,MARTES,MIERCOLES,JUEVES,VIERNES
         * Turno enum MAÑANA, TARDE, NOCHE
         * 
         * crear clases y crear objetos de prueba
        */

        System.out.println("-- profesor1 --");
        Profesor profesor1=new Profesor(1,"Hernan","Soto","ING");
        System.out.println(profesor1);

        System.out.println("-- profesor2 --");
        Profesor profesor2=new Profesor(2, "Fernanda", "Lopez", "Lic");
        System.out.println(profesor2);

        System.out.println("-- curso1 --");
        Curso curso1 = new Curso(1, "HTML", profesor2, Dia.LUNES, Turno.NOCHE);
        System.out.println(curso1);

        System.out.println("-- curso2 --");
        Curso curso2 = new Curso(
                        2,
                        "PHP", 
                        new Profesor(3, "Martina", "Pascuas", "Ing"), 
                        Dia.JUEVES, 
                        Turno.TARDE
        );
        System.out.println(curso2);

        System.out.println("-- curso3 --");
        Curso curso3=new Curso(
                        3, 
                        "Laravel", 
                        curso2.getProfesor(), 
                        Dia.VIERNES, 
                        Turno.TARDE
        );
        System.out.println(curso3);

        System.out.println("-- alumno1 --");
        Alumno alumno1=new Alumno(1, "Leandra", "Moreno", curso1);
        System.out.println(alumno1);

        Alumno alumno2=new Alumno(2, "Joaquin", "Moreno", alumno1.getCurso());
        System.out.println(alumno2);

     


    }
}