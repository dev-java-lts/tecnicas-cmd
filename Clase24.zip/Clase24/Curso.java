public class Curso {
    private int nroCurso;
    private String titulo;
    private Profesor profesor; 
    private Dia dia;
    private Turno turno;
    
    public Curso(int nroCurso, String titulo, Profesor profesor, Dia dia, Turno turno) {
        this.nroCurso = nroCurso;
        this.titulo = titulo;
        this.profesor = profesor;
        this.dia = dia;
        this.turno = turno;
    }

    @Override
    public String toString() {
        return "Curso [nroCurso=" + nroCurso + ", titulo=" + titulo + ", profesor=" + profesor + ", dia=" + dia
                + ", turno=" + turno + "]";
    }

    public int getNroCurso() {
        return nroCurso;
    }

    public void setNroCurso(int nroCurso) {
        this.nroCurso = nroCurso;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public Profesor getProfesor() {
        return profesor;
    }

    public void setProfesor(Profesor profesor) {
        this.profesor = profesor;
    }

    public Dia getDia() {
        return dia;
    }

    public void setDia(Dia dia) {
        this.dia = dia;
    }

    public Turno getTurno() {
        return turno;
    }

    public void setTurno(Turno turno) {
        this.turno = turno;
    }

}
