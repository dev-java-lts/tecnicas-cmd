public enum Dia {
    LUNES,
    MARTES,
    MIÈRCOLES,
    JUEVES,
    VIERNES
}
