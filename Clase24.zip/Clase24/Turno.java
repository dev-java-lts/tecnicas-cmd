public enum Turno {
    MAÑANA,
    TARDE,
    NOCHE
}
