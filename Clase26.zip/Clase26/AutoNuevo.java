public class AutoNuevo {
    
    private String marca;           //obligatorio
    private String modelo;          //obligatorio
    private String color;           //obligatorio
    private double precio;          //opcional
    private Radio radio;            //obligatorio

    public AutoNuevo(String marca, String modelo, String color, String marcaRadio, int potencia) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.radio = new Radio(marca, potencia);
    }

    public AutoNuevo(String marca, String modelo, String color, double precio, String marcaRadio, int potencia) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.precio = precio;
        this.radio = new Radio(marca, potencia);
    }

    @Override
    public String toString() {
        return "AutoNuevo [marca=" + marca + ", modelo=" + modelo + ", color=" + color + ", precio=" + precio
                + ", radio=" + radio + "]";
    }

     /**
     * Este método puede usarse para agregar o cambiar la radio
     */
    public void cambiarRadio(String marcaRadio, int potenciaRadio){
        this.radio = new Radio(marcaRadio, potenciaRadio);
    }

    public void pintar(String color){
        this.color=color;
    }

    public void reValuar(double precio){
        this.precio=precio;
    }

    public String getMarca() {
        return marca;
    }

    public String getModelo() {
        return modelo;
    }

    public String getColor() {
        return color;
    }

    public double getPrecio() {
        return precio;
    }

    public Radio getRadio() {
        return radio;
    }

    
    
}
