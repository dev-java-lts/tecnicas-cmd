public class Test {
    public static void main(String[] args) {
        //Objetos Mocks - Objetos simulados
        //Creamos objetos para simular el comportamiento de las clases.
        
        System.out.println("-- radio1 --");
        Radio radio1=new Radio("Sony", 60);
        System.out.println(radio1);


        System.out.println("-- autoClasico1 --");
        AutoClasico autoClasico1=new AutoClasico("Ford", "T", "Negro");
        System.out.println(autoClasico1);
        autoClasico1.pintar("Verde");
        autoClasico1.cambiarRadio("Philips", 30);
        autoClasico1.reValuar(80000);
        System.out.println(autoClasico1);

        System.out.println("-- autoClasico2 --");
        AutoClasico autoClasico2=new AutoClasico("Fiat", "500", "Blanco", 50000);
        System.out.println(autoClasico2);

        System.out.println("-- autoClasico3 --");
        //Se construye un auto sin precio y con la mismo tipo de radio que autoClasico1
        AutoClasico autoClasico3=new AutoClasico(
                                    "Renault", 
                                    "Gordini", 
                                    "Bordo", 
                                    autoClasico1.getRadio().getMarca(),
                                    autoClasico1.getRadio().getPotencia()
                                    );
        System.out.println(autoClasico3);

        System.out.println("-- autoClasico4 --");
        AutoClasico autoClasico4=new AutoClasico(
                                    "VW",
                                    "Beatle", 
                                    "Rojo", 
                                    40000,
                                    "Ken Bronw",
                                    40
                                    );
        System.out.println(autoClasico4);
        autoClasico4.pintar("Rosa");
        autoClasico4.cambiarRadio("PIONER", 80);
        autoClasico4.reValuar(60000);
        System.out.println(autoClasico4);
        
        System.out.println("-- autoNuevo1 --");
        AutoNuevo autoNuevo1 = new AutoNuevo(
                                    "Ford", 
                                    "Territory", 
                                    "Negro", 
                                    "Panasonic", 
                                    30
                                    );
        System.out.println(autoNuevo1);
        autoNuevo1.pintar("Plata");
        autoNuevo1.cambiarRadio("PIONER", 90);
        autoNuevo1.reValuar(120000);
        System.out.println(autoNuevo1);

        System.out.println("-- autoNuevo2 --");
        AutoNuevo autoNuevo2=new AutoNuevo(
                                    "Citroen", 
                                    "C5", 
                                    "Bordo", 
                                    50000, 
                                    "Philips", 
                                    30
                                    );
        System.out.println(autoNuevo2);
        

    }
}
