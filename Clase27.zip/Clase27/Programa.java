import javax.annotation.processing.SupportedOptions;

public class Programa {
    public static void main(String[] args) {
        
        System.out.println("-- dir1 --");
        Direccion dir1=new Direccion("Larrea", 258, "5", "c");
        System.out.println(dir1);

        System.out.println("-- dir --");
        Direccion dir2=new Direccion("Belgrano", 49, null, null, "Morón");
        System.out.println(dir2);

        System.out.println("-- persona1 --");
        Persona persona1=new Persona("Lorena", 34, dir2);
        System.out.println(persona1);
        persona1.saludar();

        System.out.println("-- persona2 --");
        Persona persona2=new Persona("Claudio", 34, persona1.getDireccion());
        System.out.println(persona2);
        persona2.saludar();

        System.out.println("-- persona3 --");
        Persona persona3=new Persona(
                                "Jorge",
                                26, 
                                new Direccion("Algarrobo",1041,null,null)
                        );
        System.out.println(persona3);
        persona3.saludar();

        System.out.println("-- cuenta1 --");
        Cuenta cuenta1=new Cuenta(1, "args");
        cuenta1.depositar(100000);
        cuenta1.depositar(50000);
        cuenta1.debitar(30000);
        cuenta1.debitar(200000);
        System.out.println(cuenta1);

        System.out.println("-- vendedor1 --");
        Vendedor vendedor1=new Vendedor("Leonardo", 38, dir1, 1, 3200000);
        System.out.println(vendedor1);
        vendedor1.saludar();

        System.out.println("-- vendedor2 --");
        Vendedor vendedor2=new Vendedor("Gabriela", 39, dir2, 2, 3200000);
        System.out.println(vendedor2);
        vendedor2.saludar();

        System.out.println("-- cliente1 --");
        Cliente cliente1=new Cliente("Eliana",29,dir1,1,cuenta1);
        cliente1.getCuenta().depositar(50000);
        System.out.println(cliente1);
        cliente1.saludar();

    }
}
